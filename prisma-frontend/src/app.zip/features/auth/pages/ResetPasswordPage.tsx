import { useState, type FormEvent } from "react";
import { Link, useSearchParams } from "react-router";
import { isNormalizedApiError } from "@/shared/api/normalizeError";
import { Alert } from "@/shared/ui/Alert";
import { btnPrimary, inputClass, linkClass } from "@/shared/ui/classes";
import { Field } from "@/shared/ui/Field";
import { AuthHeading } from "../components/AuthShell";
import { AUTH_ROUTES } from "../constants/auth.constants";
import { useAuthActions } from "../hooks/useAuthActions";

/** /reset-password?token=...  Rendered inside <AuthShell/> (layout route), so no wrapper here. */
export default function ResetPasswordPage() {
  const [params] = useSearchParams();
  const token = params.get("token");
  const { confirmPasswordReset, isPending } = useAuthActions();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!token) {
      setError("The link is missing its token.");
      return;
    }
    if (password !== confirm) {
      setError("Passwords do not match");
      return;
    }
    try {
      setDone(
        (await confirmPasswordReset({ token, new_password: password })).message,
      );
    } catch (err) {
      // Either the uniform "invalid token" message, or a password-policy / reuse refusal.
      setError(isNormalizedApiError(err) ? err.message : "Unexpected error");
    }
  }

  return (
    <>
      <AuthHeading
        title="Set a new password"
        subtitle="Choose a strong password you have not used before"
      />
      {done ? (
        <Alert variant="success">{done}</Alert>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          {error && <Alert>{error}</Alert>}
          <Field label="New password">
            <input
              className={inputClass}
              type="password"
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </Field>
          <Field label="Confirm new password">
            <input
              className={inputClass}
              type="password"
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              required
            />
          </Field>
          <button
            type="submit"
            className={`${btnPrimary} w-full`}
            disabled={isPending}
          >
            {isPending ? "Saving…" : "Reset password"}
          </button>
        </form>
      )}
      <Link
        className={`${linkClass} mt-4 inline-block text-sm`}
        to={AUTH_ROUTES.signIn}
      >
        Go to sign in
      </Link>
    </>
  );
}
