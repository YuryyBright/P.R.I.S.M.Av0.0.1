import { useEffect, useState, type FormEvent } from "react";
import { Link } from "react-router";
import { isNormalizedApiError } from "@/shared/api/normalizeError";
import { Alert } from "@/shared/ui/Alert";
import { btnPrimary, inputClass, linkClass } from "@/shared/ui/classes";
import { Field } from "@/shared/ui/Field";
import { PasswordInput } from "@/shared/ui/PasswordInput";
import { Spinner } from "@/shared/ui/Spinner";
import { AuthHeading } from "../components/AuthShell";
import { AUTH_ROUTES } from "../constants/auth.constants";
import { useAuthActions } from "../hooks/useAuthActions";

const RESEND_COOLDOWN_SECONDS = 30;

/**
 * Rendered inside <AuthShell/> (layout route), so no wrapper here.
 * No navigate() after login on purpose: tokenReceived flips the session to "authenticated",
 * and <GuestOnly/> redirects to the page the user originally wanted (location.state.from).
 */
export default function SignInPage() {
  const { login, resendVerification, isPending } = useAuthActions();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notVerified, setNotVerified] = useState(false);
  const [info, setInfo] = useState<string | null>(null);
  const [resending, setResending] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  // Tick the resend cooldown down once per second.
  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setNotVerified(false);
    try {
      await login({ email: email.trim(), password });
    } catch (err) {
      if (!isNormalizedApiError(err)) {
        setError("Unexpected error");
        return;
      }
      setError(err.message); // the backend attaches every login failure to field "email"; one banner is enough
      // Fragile: matches the text "Email is not verified." (no error code from the backend).
      setNotVerified(/not verified/i.test(err.message));
    }
  }

  async function resend() {
    setResending(true);
    setInfo(null);
    try {
      const res = await resendVerification({ email: email.trim() });
      setError(null); // avoid showing "not verified" and "sent" at the same time
      setInfo(res.message);
      setCooldown(RESEND_COOLDOWN_SECONDS);
    } catch (err) {
      setError(isNormalizedApiError(err) ? err.message : "Unexpected error");
    } finally {
      setResending(false);
    }
  }

  return (
    <>
      <AuthHeading
        title="Welcome back"
        subtitle="Sign in with your email and password"
      />
      <form onSubmit={submit} className="space-y-5">
        <div aria-live="polite" className="space-y-3 empty:hidden">
          {error && <Alert>{error}</Alert>}
          {info && <Alert variant="success">{info}</Alert>}
          {(notVerified || info) && (
            <div className="flex items-center justify-between gap-3 rounded-lg border border-gray-200 bg-gray-50 px-3.5 py-3 text-sm dark:border-gray-800 dark:bg-white/5">
              <span className="text-gray-600 dark:text-gray-400">
                Didn't get the email?
              </span>
              <button
                type="button"
                className={`${linkClass} inline-flex items-center gap-2 disabled:cursor-not-allowed disabled:opacity-60`}
                onClick={() => void resend()}
                disabled={resending || cooldown > 0 || !email.trim()}
              >
                {resending && <Spinner className="size-3.5" />}
                {cooldown > 0
                  ? `Resend in ${cooldown}s`
                  : "Resend verification email"}
              </button>
            </div>
          )}
        </div>

        <Field label="Email">
          <input
            className={inputClass}
            type="email"
            autoComplete="username"
            placeholder="you@example.com"
            autoFocus
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </Field>

        <div>
          <Field label="Password">
            <PasswordInput
              autoComplete="current-password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </Field>
          <div className="mt-2 flex justify-end text-sm">
            <Link className={linkClass} to={AUTH_ROUTES.forgotPassword}>
              Forgot password?
            </Link>
          </div>
        </div>

        <button
          type="submit"
          className={`${btnPrimary} inline-flex w-full items-center justify-center gap-2`}
          disabled={isPending}
        >
          {isPending && <Spinner />}
          {isPending ? "Signing in…" : "Sign in"}
        </button>

        <p className="text-center text-sm text-gray-500 dark:text-gray-400">
          Don't have an account?{" "}
          <Link className={linkClass} to={AUTH_ROUTES.signUp}>
            Create one
          </Link>
        </p>
      </form>
    </>
  );
}
