import type { ReactNode } from "react";
import { Link, Outlet } from "react-router";
import GridShape from "@/components/common/GridShape";
import ThemeTogglerTwo from "@/components/common/ThemeTogglerTwo";

const BRAND_TAGLINE = "Your product tagline"; // TODO: replace or move to i18n
const BRAND_SUBTEXT = "One short sentence about what the product does."; // TODO: replace or move to i18n

/**
 * ONE shell for every public auth page (sign-in, sign-up, forgot/reset password, verify email).
 * Used as a LAYOUT ROUTE in the router: pages render only their own heading + form,
 * so the split-screen markup lives here and nowhere else.
 *
 * - Left column scrolls on its own, so tall forms (sign-up) are never clipped on small screens.
 * - `my-auto` (not justify-center) keeps short forms centered AND lets tall ones scroll from the top.
 * - Right column is hidden below lg, so the logo is repeated at the top of the left column there.
 */
export function AuthShell() {
  return (
    <div className="relative z-1 min-h-screen bg-white lg:flex lg:h-screen dark:bg-gray-900">
      {/* left column: the page (<SignInPage/>, <SignUpPage/> ...) */}
      <div className="flex min-h-screen w-full flex-col overflow-y-auto px-6 py-8 sm:px-10 lg:min-h-0 lg:w-1/2">
        <Link to="/" className="mx-auto w-full max-w-md lg:hidden">
          {/* assumes the stock TailAdmin logo files; adjust the paths if yours differ */}
          <img
            className="h-8 dark:hidden"
            src="/images/logo/logo.svg"
            alt="Logo"
          />
          <img
            className="hidden h-8 dark:block"
            src="/images/logo/logo-dark.svg"
            alt="Logo"
          />
        </Link>
        <div className="mx-auto my-auto w-full max-w-md py-8">
          <Outlet />
        </div>
      </div>

      {/* right column: branding, identical for all auth pages */}
      <aside className="relative isolate hidden w-1/2 items-center justify-center overflow-hidden bg-brand-950 lg:flex dark:bg-white/5">
        {/* soft glow behind the logo; first in DOM so the grid paints over it */}
        <div className="pointer-events-none absolute inset-0 -z-1 bg-[radial-gradient(55%_45%_at_50%_45%,rgba(70,95,255,0.35),transparent)]" />
        <GridShape />
        <div className="relative z-1 flex max-w-sm flex-col items-center px-6 text-center">
          <Link to="/" className="mb-8 block">
            <img
              width={231}
              height={48}
              src="/images/logo/auth-logo.svg"
              alt="Logo"
            />
          </Link>
          <h2 className="text-title-sm font-semibold text-white/90">
            {BRAND_TAGLINE}
          </h2>
          <p className="mt-3 text-sm text-gray-400 dark:text-white/60">
            {BRAND_SUBTEXT}
          </p>
        </div>
      </aside>

      <div className="fixed inset-e-6 bottom-6 z-50 hidden sm:block">
        <ThemeTogglerTwo />
      </div>
    </div>
  );
}

/** Title block that each auth page puts above its form. Inherits text alignment from the page. */
export function AuthHeading({
  title,
  subtitle,
}: {
  title: string;
  subtitle?: string;
}): ReactNode {
  return (
    <div className="mb-6 sm:mb-8">
      <h1 className="mb-2 text-title-sm font-semibold text-gray-800 sm:text-title-md dark:text-white/90">
        {title}
      </h1>
      {subtitle && (
        <p className="text-sm text-gray-500 dark:text-gray-400">{subtitle}</p>
      )}
    </div>
  );
}
