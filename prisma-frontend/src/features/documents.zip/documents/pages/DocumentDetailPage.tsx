import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link, useNavigate, useParams, useSearchParams } from "react-router";
import { Can } from "@/features/auth";
import { isNormalizedApiError } from "@/shared/api/normalizeError";
import { Alert } from "@/shared/ui/Alert";
import { useGetDocumentDetailsQuery } from "../api/documents.endpoints";
import { DeleteDocumentDialog } from "../components/DeleteDocumentDialog";
import { DocumentActions } from "../components/DocumentActions";
import { DocumentChunksTab } from "../components/DocumentChunksTab";
import { ChevronRightIcon, FileIcon } from "../components/DocumentIcons";
import { DocumentInfoTab } from "../components/DocumentInfoTab";
import { DocumentStatusBadge } from "../components/DocumentStatusBadge";
import { RenameDocumentModal } from "../components/RenameDocumentModal";
import {
  DOCUMENTS_ROUTES,
  DOCUMENT_PERMISSIONS,
  POLL_INTERVAL_MS,
} from "../constants/documents.constants";
import { useDocumentActions } from "../hooks/useDocumentActions";
import { formatBytes, isActiveStatus } from "../lib/documentFormat";
import type { DocumentDetails, DocumentItem } from "../types/document.types";

type Tab = "chunks" | "info";
type Dialog = "rename" | "delete" | null;

const linkClass =
  "rounded transition-colors hover:text-gray-800 focus-visible:ring-2 focus-visible:ring-brand-500/40 focus-visible:outline-none dark:hover:text-white/90";
const skeleton =
  "animate-pulse rounded-lg bg-gray-100 motion-reduce:animate-none dark:bg-white/5";

/** Actions/dialogs are typed against the list row; the card has a superset of its fields. */
const toItem = (d: DocumentDetails): DocumentItem => ({
  id: d.id,
  collection_id: d.collection_id,
  title: d.title,
  filename: d.filename,
  mime_type: d.mime_type,
  size_bytes: d.size_bytes,
  source_type: d.source_type,
  status: d.status,
  created_at: d.created_at ?? "",
});

/**
 * /collections/:collectionId/documents/:documentId
 * Header + tabs: «Чанки» (overview strip, list, reader) and «Інформація» (metadata).
 * Access is decided by the backend: 404 = missing / no access.
 */
export default function DocumentDetailPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { collectionId = "", documentId = "" } = useParams();
  const [params, setParams] = useSearchParams();
  const tab: Tab = params.get("tab") === "info" ? "info" : "chunks";
  const [dialog, setDialog] = useState<Dialog>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const { reindexDocument } = useDocumentActions();

  // Poll only while the worker is busy; the flag follows the card's own status.
  const [live, setLive] = useState(true);
  const { data, error, isLoading } = useGetDocumentDetailsQuery(documentId, {
    pollingInterval: live ? POLL_INTERVAL_MS : 0,
    skipPollingIfUnfocused: true,
  });
  const active = data ? isActiveStatus(data.status) : false;
  useEffect(() => {
    if (data) setLive(active);
  }, [data, active]);

  useEffect(() => {
    if (data?.title) document.title = data.title;
  }, [data?.title]);

  const setTab = (next: Tab) =>
    setParams(
      (prev) => {
        const p = new URLSearchParams(prev);
        if (next === "chunks") p.delete("tab");
        else p.set("tab", next);
        return p;
      },
      { replace: true },
    );

  const toCollection = DOCUMENTS_ROUTES.collection(collectionId);

  if (isLoading) {
    return (
      <div aria-busy="true" className="space-y-6">
        <span className="sr-only">{t("common.loading")}</span>
        <div className={`${skeleton} h-4 w-64`} />
        <div className={`${skeleton} h-28 w-full rounded-2xl`} />
        <div className={`${skeleton} h-12 w-full rounded-2xl`} />
        <div className={`${skeleton} h-96 w-full rounded-2xl`} />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="space-y-4">
        <Link
          to={toCollection}
          className={`inline-flex items-center gap-1.5 text-theme-sm text-gray-500 dark:text-gray-400 ${linkClass}`}
        >
          {t("documents.detail.back", "До колекції")}
        </Link>
        <Alert>
          {(error as { message?: string } | undefined)?.message ??
            t(
              "documents.details.loadError",
              "Не вдалося завантажити інформацію про документ",
            )}
        </Alert>
      </div>
    );
  }

  const item = toItem(data);
  // The card returns acl_count only to users with WRITE on the collection.
  const canWrite = data.acl_count !== null;

  async function reindex() {
    setActionError(null);
    try {
      await reindexDocument(item.id, item.collection_id);
    } catch (e) {
      setActionError(
        isNormalizedApiError(e) ? e.message : t("errors.unexpected"),
      );
    }
  }

  const facts = [
    formatBytes(data.size_bytes),
    data.chunks.total > 0
      ? `${data.chunks.total.toLocaleString()} ${t("documents.detail.chunksWord", "чанків")}`
      : null,
    data.chunks.total_tokens > 0
      ? `${data.chunks.total_tokens.toLocaleString()} ${t("documents.chunks.tokens", "ток.")}`
      : null,
    data.chunks.max_page
      ? `${data.chunks.max_page} ${t("documents.detail.pagesWord", "стор.")}`
      : null,
  ].filter(Boolean);

  const tabs: { id: Tab; label: string }[] = [
    {
      id: "chunks",
      label: `${t("documents.chunks.title", "Чанки")}${data.chunks.total ? ` · ${data.chunks.total}` : ""}`,
    },
    { id: "info", label: t("documents.detail.tabInfo", "Інформація") },
  ];

  return (
    <div className="space-y-6">
      <nav aria-label={t("common.breadcrumb", "Навігаційний ланцюжок")}>
        <ol className="flex items-center gap-1.5 text-theme-sm text-gray-500 dark:text-gray-400">
          <li className="shrink-0">
            <Link to={DOCUMENTS_ROUTES.collections} className={linkClass}>
              {t("collections.title")}
            </Link>
          </li>
          <li aria-hidden="true" className="flex shrink-0 items-center">
            <ChevronRightIcon className="size-4" />
          </li>
          <li className="min-w-0 shrink">
            <Link to={toCollection} className={`block truncate ${linkClass}`}>
              {data.collection_name ??
                t("documents.detail.collection", "Колекція")}
            </Link>
          </li>
          <li aria-hidden="true" className="flex shrink-0 items-center">
            <ChevronRightIcon className="size-4" />
          </li>
          <li className="min-w-0 flex-1">
            <span
              aria-current="page"
              className="block truncate font-medium text-gray-800 dark:text-white/90"
            >
              {data.title}
            </span>
          </li>
        </ol>
      </nav>

      <header className="flex flex-col gap-5 rounded-2xl border border-gray-200 bg-white p-5 md:flex-row md:items-start md:justify-between md:p-6 dark:border-white/5 dark:bg-white/3">
        <div className="flex min-w-0 flex-1 items-start gap-4">
          <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-gray-50 text-gray-500 ring-1 ring-gray-200/70 ring-inset dark:bg-white/5 dark:text-gray-400 dark:ring-white/5">
            <FileIcon className="size-6" />
          </span>
          <div className="min-w-0 flex-1 space-y-2.5">
            <h1 className="text-title-sm font-semibold wrap-break-word text-gray-800 dark:text-white/90">
              {data.title}
            </h1>
            {data.filename && data.filename !== data.title && (
              <p
                className="truncate text-theme-sm text-gray-500 dark:text-gray-400"
                title={data.filename}
              >
                {data.filename}
              </p>
            )}
            <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
              <DocumentStatusBadge status={data.status} />
              {facts.length > 0 && (
                <span className="text-theme-xs text-gray-500 dark:text-gray-400">
                  {facts.join(" · ")}
                </span>
              )}
            </div>
          </div>
        </div>

        {canWrite && (
          <Can permission={DOCUMENT_PERMISSIONS.write}>
            <DocumentActions
              document={item}
              canWrite
              variant="labeled"
              className="flex-wrap md:justify-end"
              onRename={() => setDialog("rename")}
              onReindex={reindex}
              onDelete={() => setDialog("delete")}
            />
          </Can>
        )}
      </header>

      {actionError && <Alert>{actionError}</Alert>}

      <div
        role="tablist"
        aria-label={t("documents.detail.sections", "Розділи документа")}
        className="flex gap-1 border-b border-gray-200 dark:border-white/10"
      >
        {tabs.map((x) => (
          <button
            key={x.id}
            role="tab"
            type="button"
            id={`doc-tab-${x.id}`}
            aria-selected={tab === x.id}
            aria-controls={`doc-panel-${x.id}`}
            tabIndex={tab === x.id ? 0 : -1}
            onClick={() => setTab(x.id)}
            className={`-mb-px border-b-2 px-4 py-2.5 text-theme-sm font-medium transition-colors focus-visible:ring-2 focus-visible:ring-brand-500/40 focus-visible:outline-none ${
              tab === x.id
                ? "border-brand-500 text-brand-600 dark:border-brand-400 dark:text-brand-400"
                : "border-transparent text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white/90"
            }`}
          >
            {x.label}
          </button>
        ))}
      </div>

      <div
        role="tabpanel"
        id={`doc-panel-${tab}`}
        aria-labelledby={`doc-tab-${tab}`}
      >
        {tab === "chunks" ? (
          <DocumentChunksTab
            documentId={data.id}
            status={data.status}
            active={active}
          />
        ) : (
          <DocumentInfoTab data={data} />
        )}
      </div>

      {dialog === "rename" && (
        <RenameDocumentModal
          key={item.id}
          document={item}
          onClose={() => setDialog(null)}
        />
      )}
      {dialog === "delete" && (
        <DeleteDocumentDialog
          document={item}
          onClose={() => setDialog(null)}
          onDeleted={() => navigate(toCollection, { replace: true })}
        />
      )}
    </div>
  );
}
